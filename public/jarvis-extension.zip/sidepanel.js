const nextjsFrame = document.getElementById("nextjsFrame");
const sandboxFrame = document.getElementById("sandboxFrame");
let currentChatId = Date.now().toString();

// Dynamic URL loading
async function initNextjsFrame() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1500); // 1.5s timeout
    const res = await fetch("http://localhost:3000/api/auth/session", { method: "GET", signal: controller.signal });
    clearTimeout(timeoutId);
    
    // Any response (even if unauthorized or empty session) means the server is running on port 3000
    if (res.status === 200 || res.status === 401 || res.status === 307) {
      nextjsFrame.src = "http://localhost:3000/extension-panel?env=local";
    } else {
      nextjsFrame.src = "https://assistant-nine-ecru.vercel.app/extension-panel";
    }
  } catch (err) {
    // Fallback to remote if localhost fetch fails
    nextjsFrame.src = "https://assistant-nine-ecru.vercel.app/extension-panel";
  }
}
initNextjsFrame();

// --- 1. Forward Chat History to Next.js ---
async function syncChatToSaved(history) {
  const data = await chrome.storage.local.get({ savedChats: [] });
  let savedChats = data.savedChats;
  
  let activeChat = savedChats.find(c => c.id === currentChatId);
  if (!activeChat) {
    activeChat = {
      id: currentChatId,
      title: "New Chat",
      timestamp: Date.now(),
      messages: []
    };
    savedChats.unshift(activeChat);
  }
  
  activeChat.messages = history;
  
  // Auto-generate title from first user message
  if (activeChat.title === "New Chat" && history.length > 0) {
    const firstUserMsg = history.find(m => m.role === "user");
    if (firstUserMsg) {
      activeChat.title = firstUserMsg.text.substring(0, 30) + (firstUserMsg.text.length > 30 ? "..." : "");
    }
  }
  
  await chrome.storage.local.set({ savedChats });
}

async function sendInitialState() {
  const data = await chrome.storage.local.get({ 
    chatHistory: [], 
    savedChats: [], 
    isAgentRunning: false, 
    currentTokenUsage: null,
    settings: {
      sandboxEnabled: true,
      maxActions: 75,
      desktopAlerts: true,
      soundAlerts: false,
      verboseLogs: false,
      stealthMode: false,
      autoSaveEnabled: false,
      autoSavePath: "/JarvisLogs"
    }
  });
  if (nextjsFrame && nextjsFrame.contentWindow) {
    nextjsFrame.contentWindow.postMessage({
      type: "FROM_EXTENSION",
      action: "UPDATE_STATE",
      history: data.chatHistory,
      savedChats: data.savedChats,
      isAgentRunning: data.isAgentRunning,
      currentTokenUsage: data.currentTokenUsage,
      currentChatId: currentChatId,
      settings: data.settings
    }, "*");
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    if (changes.chatHistory) {
      syncChatToSaved(changes.chatHistory.newValue);
      if (nextjsFrame && nextjsFrame.contentWindow) {
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "UPDATE_STATE",
          history: changes.chatHistory.newValue
        }, "*");
      }
    }
    if (changes.savedChats) {
      if (nextjsFrame && nextjsFrame.contentWindow) {
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "UPDATE_STATE",
          savedChats: changes.savedChats.newValue
        }, "*");
      }
    }
    if (changes.isAgentRunning) {
      if (nextjsFrame && nextjsFrame.contentWindow) {
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "UPDATE_STATE",
          isAgentRunning: changes.isAgentRunning.newValue
        }, "*");
      }
    }
    if (changes.currentTokenUsage) {
      if (nextjsFrame && nextjsFrame.contentWindow) {
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "UPDATE_STATE",
          currentTokenUsage: changes.currentTokenUsage.newValue
        }, "*");
      }
    }
    if (changes.settings) {
      if (nextjsFrame && nextjsFrame.contentWindow) {
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "UPDATE_STATE",
          settings: changes.settings.newValue
        }, "*");
      }
    }
  }
});

// --- 2. Listen to Messages from Iframes (Next.js & Sandbox) ---
window.addEventListener("message", async (event) => {
  const data = event.data;
  if (!data) return;

  // -- Messages from Sandbox --
  if (data.action === "command") {
    const { command, args } = data;
    const port = event.ports[0];

    chrome.runtime.sendMessage({
      action: "execute_sandbox_command",
      command,
      args
    }, (response) => {
      if (chrome.runtime.lastError) {
        port.postMessage({ success: false, error: chrome.runtime.lastError.message });
      } else {
        port.postMessage(response);
      }
    });
    return;
  }

  if (data.action === "result") {
    chrome.runtime.sendMessage({
      action: "log_sandbox_result",
      success: data.success,
      result: data.result,
      error: data.error,
      messageId: data.messageId,
      isManual: data.isManual
    });

    if (nextjsFrame && nextjsFrame.contentWindow) {
      nextjsFrame.contentWindow.postMessage({
        type: "FROM_EXTENSION",
        action: "WORKFLOW_RESULT",
        messageId: data.messageId,
        success: data.success,
        error: data.error
      }, "*");
    }
    return;
  }

  // -- Messages from Next.js UI --
  if (data.type === "FROM_NEXTJS") {
    switch (data.action) {
      case "REQUEST_INITIAL_STATE":
        sendInitialState();
        break;

      case "SAVE_SETTINGS":
        if (data.settings) {
          // If desktop alerts are enabled, check OS permissions
          if (data.settings.desktopAlerts) {
            chrome.notifications.getPermissionLevel((level) => {
              if (level === "denied") {
                nextjsFrame.contentWindow.postMessage({
                  type: "FROM_EXTENSION",
                  action: "NOTIFICATION_PERMISSION_DENIED"
                }, "*");
              }
            });
          }
          await chrome.storage.local.set({ settings: data.settings });
        }
        break;

      case "RELOAD_EXTENSION":
        chrome.runtime.reload();
        break;

      case "NEW_CHAT":
        currentChatId = Date.now().toString();
        await chrome.storage.local.set({ chatHistory: [], currentTokenUsage: null });
        sendInitialState();
        break;

      case "LOAD_CHAT":
        currentChatId = data.chatId;
        const savedData = await chrome.storage.local.get({ savedChats: [] });
        const chatToLoad = savedData.savedChats.find(c => c.id === data.chatId);
        if (chatToLoad) {
          await chrome.storage.local.set({ chatHistory: chatToLoad.messages || [] });
        }
        const usageData = await chrome.storage.local.get(`tokenUsage_${data.chatId}`);
        await chrome.storage.local.set({ currentTokenUsage: usageData[`tokenUsage_${data.chatId}`] || null });
        sendInitialState();
        break;

      case "DELETE_CHAT":
        const saved = await chrome.storage.local.get({ savedChats: [] });
        const filtered = saved.savedChats.filter(c => c.id !== data.chatId);
        await chrome.storage.local.set({ savedChats: filtered });
        if (currentChatId === data.chatId) {
          currentChatId = Date.now().toString();
          await chrome.storage.local.set({ chatHistory: [] });
        }
        break;

      case "RUN_AGENT":
        const currentData = await chrome.storage.local.get({ chatHistory: [] });
        const newHistory = currentData.chatHistory;
        newHistory.push({ role: "user", text: data.prompt, tags: data.tags || [], timestamp: Date.now() });
        await chrome.storage.local.set({ chatHistory: newHistory });

        chrome.runtime.sendMessage({
          action: "run_agent",
          prompt: data.prompt,
          tags: data.tags || [],
          model: data.model || "mistral-small-latest",
          chatId: currentChatId
        });
        break;

      case "DELETE_MESSAGE": {
        const histData = await chrome.storage.local.get({ chatHistory: [] });
        const history = histData.chatHistory;
        history.splice(data.index);
        await chrome.storage.local.set({ chatHistory: history });
        break;
      }

      case "RETRY_MESSAGE": {
        const histData = await chrome.storage.local.get({ chatHistory: [] });
        const history = histData.chatHistory;
        if (history[data.index]) {
          const targetMsg = history[data.index];
          // Truncate history after the target user message
          history.splice(data.index + 1);
          await chrome.storage.local.set({ chatHistory: history });

          // Re-trigger the agent running loop
          chrome.runtime.sendMessage({
            action: "run_agent",
            prompt: targetMsg.text,
            tags: targetMsg.tags || [],
            model: data.model || "mistral-small-latest",
            chatId: currentChatId
          });
        }
        break;
      }

      case "EDIT_MESSAGE": {
        const histData = await chrome.storage.local.get({ chatHistory: [] });
        const history = histData.chatHistory;
        if (history[data.index]) {
          history[data.index].text = data.text;
          history[data.index].timestamp = Date.now();
        }
        await chrome.storage.local.set({ chatHistory: history });
        break;
      }

      case "RUN_WORKFLOW":
        await chrome.runtime.sendMessage({ action: "log_sandbox_start" });
        nextjsFrame.contentWindow.postMessage({
          type: "FROM_EXTENSION",
          action: "execute",
          script: data.script,
          inputs: data.inputs,
          messageId: data.messageId,
          isManual: data.isManual
        }, "*");
        break;

      case "REQUEST_OPEN_TABS":
        chrome.tabs.query({ currentWindow: true }, (tabs) => {
          if (nextjsFrame && nextjsFrame.contentWindow) {
            nextjsFrame.contentWindow.postMessage({
              type: "FROM_EXTENSION",
              action: "OPEN_TABS_RESULT",
              tabs: tabs.map(t => ({ id: t.id, title: t.title, url: t.url }))
            }, "*");
          }
        });
        break;

      case "REQUEST_RECENT_PAGES":
        chrome.history.search({ text: '', maxResults: 50 }, (historyItems) => {
          if (nextjsFrame && nextjsFrame.contentWindow) {
            nextjsFrame.contentWindow.postMessage({
              type: "FROM_EXTENSION",
              action: "RECENT_PAGES_RESULT",
              pages: historyItems.map(h => ({ id: h.id, title: h.title, url: h.url }))
            }, "*");
          }
        });
        break;

      case "STOP_AGENT":
        await chrome.storage.local.set({ agentStopRequested: true });
        break;

      case "OPEN_LOGIN_PAGE": {
        const url = nextjsFrame.src.includes("localhost") 
          ? "http://localhost:3000/api/auth/signin" 
          : "https://assistant-nine-ecru.vercel.app/api/auth/signin";
        chrome.tabs.create({ url });
        break;
      }
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "RUN_WORKFLOW_SANDBOX") {
    chrome.runtime.sendMessage({ action: "log_sandbox_start" });
    nextjsFrame.contentWindow.postMessage({
      type: "FROM_EXTENSION",
      action: "execute",
      script: message.script,
      inputs: message.inputs || {},
      messageId: message.messageId
    }, "*");
    sendResponse({ success: true, message: "Workflow dispatched to sandbox" });
  } else if (message.action === "TRIGGER_RUN_WORKFLOW") {
    if (nextjsFrame && nextjsFrame.contentWindow) {
      nextjsFrame.contentWindow.postMessage({
        type: "FROM_EXTENSION",
        action: "TRIGGER_RUN_WORKFLOW",
        workflowId: message.workflowId,
        inputs: message.inputs || {}
      }, "*");
    }
  } else if (message.action === "PLAY_SOUND") {
    if (nextjsFrame && nextjsFrame.contentWindow) {
      nextjsFrame.contentWindow.postMessage({
        type: "FROM_EXTENSION",
        action: message.action
      }, "*");
    }
  } else if (message.action === "TRIGGER_DOWNLOAD") {
    // Perform download directly in sidepanel.js context to bypass Firefox cross-origin iframe download blocks
    try {
      const content = message.history.map(m => {
        const date = new Date(m.timestamp || Date.now()).toLocaleTimeString();
        return `[${date}] ${m.role.toUpperCase()}: ${m.text}`;
      }).join("\n\n");
      
      const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
      const blobUrl = URL.createObjectURL(blob);
      
      const cleanPath = (message.path || "").replace(/^\/+|\/+$/g, "");
      const folderName = cleanPath.split("/").pop() || "JarvisLogs";
      const filename = `${folderName}_chat_log_${Date.now()}.md`;
      
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
    } catch (err) {
      console.error("Sidepanel download failed:", err);
    }
  }
});

